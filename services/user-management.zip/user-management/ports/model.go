package ports

type UserManagement struct {
	Id         string
	IntProp    int
	StringProp string
}
